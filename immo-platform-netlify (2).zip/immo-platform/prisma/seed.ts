import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  const senegal = await prisma.country.upsert({
    where: { code: "SN" },
    update: {},
    create: { name: "Sénégal", code: "SN" },
  });

  const dakar = await prisma.city.upsert({
    where: { name_countryId: { name: "Dakar", countryId: senegal.id } },
    update: {},
    create: { name: "Dakar", countryId: senegal.id },
  });

  const categorie = await prisma.category.upsert({
    where: { slug: "villa" },
    update: {},
    create: { name: "Villa", slug: "villa" },
  });

  const passwordHash = await bcrypt.hash("motdepasse123", 12);

  const admin = await prisma.user.upsert({
    where: { email: "admin@terangaimmo.com" },
    update: {},
    create: {
      email: "admin@terangaimmo.com",
      passwordHash,
      firstName: "Admin",
      lastName: "TerangaImmo",
      role: "ADMIN",
    },
  });

  await prisma.property.upsert({
    where: { slug: "villa-demo-almadies" },
    update: {},
    create: {
      title: "Villa moderne aux Almadies",
      slug: "villa-demo-almadies",
      description:
        "Magnifique villa 5 pièces avec piscine, jardin arboré et vue dégagée. Idéale pour une famille recherchant calme et standing à proximité de la mer.",
      type: "VENTE",
      status: "PUBLIEE",
      price: 185000000,
      currency: "XOF",
      surface: 320,
      rooms: 5,
      bedrooms: 4,
      bathrooms: 3,
      address: "Route des Almadies",
      cityId: dakar.id,
      categoryId: categorie.id,
      ownerId: admin.id,
    },
  });

  await prisma.package.upsert({
    where: { type: "GRATUIT" },
    update: {},
    create: { type: "GRATUIT", name: "Gratuit", priceMonthly: 0, maxListings: 2, boostsIncluded: 0, features: {} },
  });
  await prisma.package.upsert({
    where: { type: "STANDARD" },
    update: {},
    create: { type: "STANDARD", name: "Standard", priceMonthly: 9, maxListings: 10, boostsIncluded: 1, features: {} },
  });
  await prisma.package.upsert({
    where: { type: "PREMIUM" },
    update: {},
    create: { type: "PREMIUM", name: "Premium", priceMonthly: 29, maxListings: 50, boostsIncluded: 5, features: {} },
  });
  await prisma.package.upsert({
    where: { type: "PROFESSIONNEL" },
    update: {},
    create: { type: "PROFESSIONNEL", name: "Professionnel", priceMonthly: 79, maxListings: 999, boostsIncluded: 20, features: {} },
  });

  console.log("Seed terminé. Compte admin : admin@terangaimmo.com / motdepasse123");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
