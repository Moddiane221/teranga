import Stripe from "stripe";

export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY as string, {
  apiVersion: "2024-06-20",
});

/**
 * Crée une session de paiement Stripe Checkout pour un pack (abonnement) ou un boost d'annonce.
 * Retourne l'URL vers laquelle rediriger l'utilisateur.
 */
export async function createStripeCheckoutSession(params: {
  amount: number; // en unité principale (ex: 19.99), pas en centimes
  currency: string;
  productName: string;
  successUrl: string;
  cancelUrl: string;
  metadata: Record<string, string>;
}) {
  const session = await stripe.checkout.sessions.create({
    mode: "payment",
    payment_method_types: ["card"],
    line_items: [
      {
        price_data: {
          currency: params.currency.toLowerCase(),
          product_data: { name: params.productName },
          unit_amount: Math.round(params.amount * 100),
        },
        quantity: 1,
      },
    ],
    success_url: params.successUrl,
    cancel_url: params.cancelUrl,
    metadata: params.metadata,
  });

  return session;
}

/**
 * Vérifie la signature d'un webhook Stripe et retourne l'événement.
 * À utiliser dans la route /api/payments/stripe/webhook.
 */
export function constructStripeEvent(rawBody: string, signature: string) {
  return stripe.webhooks.constructEvent(
    rawBody,
    signature,
    process.env.STRIPE_WEBHOOK_SECRET as string
  );
}
