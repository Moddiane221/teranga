import type { PaymentProviderAdapter } from "./types";

/**
 * Adaptateur orangeMoney — SQUELETTE À COMPLÉTER.
 *
 * Chaque opérateur de mobile money / paiement a ses propres identifiants
 * marchands, formats de requête et mécanismes de signature de webhook, qui
 * ne peuvent être obtenus qu'en créant un vrai compte marchand auprès du
 * fournisseur. Ce fichier fournit la structure attendue par le reste de
 * l'application (voir types.ts) ; il reste à brancher les vrais appels API
 * une fois le contrat marchand signé et la documentation technique du
 * fournisseur en main.
 *
 * Étapes concrètes à suivre :
 * 1. Créer un compte marchand / développeur chez orangeMoney.
 * 2. Récupérer les clés API et les placer dans .env (voir .env.example).
 * 3. Implémenter initiate() : appel HTTP vers l'API du fournisseur pour
 *    créer la transaction, retourner l'URL de paiement ou la référence.
 * 4. Implémenter verify() : valider la signature du webhook reçu et
 *    retourner le statut réel de la transaction.
 * 5. Ajouter la route API correspondante sous
 *    src/app/api/payments/orangeMoney/ (checkout + webhook), sur le modèle
 *    de src/app/api/payments/stripe/.
 */
export const orangeMoneyAdapter: PaymentProviderAdapter = {
  async initiate(params) {
    throw new Error(
      "Intégration orangeMoney non configurée : voir le commentaire en tête de ce fichier."
    );
  },

  async verify(payload) {
    throw new Error(
      "Intégration orangeMoney non configurée : voir le commentaire en tête de ce fichier."
    );
  },
};
