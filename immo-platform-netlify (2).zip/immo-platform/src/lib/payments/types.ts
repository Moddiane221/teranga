// Interface commune à tous les fournisseurs de paiement.
// Chaque fournisseur (Stripe, PayPal, Wave, Orange Money, Free Money, Unitech Pay)
// doit exposer une fonction `initiate` qui démarre le paiement et retourne une URL
// ou une référence à afficher/rediriger côté client, ainsi qu'un `verify` appelé
// par le webhook pour confirmer la transaction avant d'activer l'abonnement/le boost.

export type PaymentInitResult = {
  redirectUrl?: string; // pour les fournisseurs qui renvoient vers une page de paiement
  providerRef: string; // identifiant de transaction à stocker dans Payment.providerRef
  raw?: unknown;
};

export interface PaymentProviderAdapter {
  initiate(params: {
    amount: number;
    currency: string;
    orderId: string;
    description: string;
    customerPhone?: string;
    returnUrl: string;
  }): Promise<PaymentInitResult>;

  verify(payload: unknown): Promise<{ success: boolean; providerRef: string }>;
}
