import jwt from "jsonwebtoken";
import bcrypt from "bcryptjs";
import { NextRequest } from "next/server";

const JWT_SECRET = process.env.JWT_SECRET as string;
const TOKEN_COOKIE = "immo_session";
const TOKEN_TTL = "7d";

export type SessionPayload = {
  userId: string;
  role: "ADMIN" | "AGENCE" | "AGENT" | "PROPRIETAIRE" | "ACHETEUR";
  email: string;
};

export async function hashPassword(password: string) {
  return bcrypt.hash(password, 12);
}

export async function verifyPassword(password: string, hash: string) {
  return bcrypt.compare(password, hash);
}

export function signSession(payload: SessionPayload) {
  if (!JWT_SECRET) throw new Error("JWT_SECRET manquant dans les variables d'environnement");
  return jwt.sign(payload, JWT_SECRET, { expiresIn: TOKEN_TTL });
}

export function verifySession(token: string): SessionPayload | null {
  try {
    return jwt.verify(token, JWT_SECRET) as SessionPayload;
  } catch {
    return null;
  }
}

export function getSessionFromRequest(req: NextRequest): SessionPayload | null {
  const token = req.cookies.get(TOKEN_COOKIE)?.value;
  if (!token) return null;
  return verifySession(token);
}

export const SESSION_COOKIE_NAME = TOKEN_COOKIE;

// Vérifie qu'un rôle fait partie d'une liste de rôles autorisés (pour protéger une route API)
export function requireRole(session: SessionPayload | null, allowed: SessionPayload["role"][]) {
  if (!session) return false;
  return allowed.includes(session.role);
}
