"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";

export default function SearchBar() {
  const router = useRouter();
  const [q, setQ] = useState("");
  const [type, setType] = useState("");
  const [ville, setVille] = useState("");

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const params = new URLSearchParams();
    if (q) params.set("q", q);
    if (type) params.set("type", type);
    if (ville) params.set("ville", ville);
    router.push(`/annonces?${params.toString()}`);
  }

  return (
    <form
      onSubmit={handleSubmit}
      className="bg-white rounded-2xl shadow-lg p-3 flex flex-col md:flex-row gap-2 w-full max-w-3xl"
    >
      <input
        value={q}
        onChange={(e) => setQ(e.target.value)}
        placeholder="Ville, quartier, type de bien..."
        className="flex-1 rounded-xl px-4 py-3 bg-indigo-950/5 text-sm focus:outline-none"
      />
      <select
        value={type}
        onChange={(e) => setType(e.target.value)}
        className="rounded-xl px-4 py-3 bg-indigo-950/5 text-sm"
      >
        <option value="">Tout type</option>
        <option value="VENTE">Vente</option>
        <option value="LOCATION">Location</option>
        <option value="LOCATION_SAISONNIERE">Saisonnière</option>
        <option value="TERRAIN">Terrain</option>
        <option value="COMMERCE">Commerce</option>
        <option value="HOTEL">Hôtel</option>
      </select>
      <input
        value={ville}
        onChange={(e) => setVille(e.target.value)}
        placeholder="Ville"
        className="rounded-xl px-4 py-3 bg-indigo-950/5 text-sm md:w-40"
      />
      <button
        type="submit"
        className="rounded-xl bg-sunset text-white font-semibold px-6 py-3 text-sm hover:bg-baobab transition-colors"
      >
        Rechercher
      </button>
    </form>
  );
}
