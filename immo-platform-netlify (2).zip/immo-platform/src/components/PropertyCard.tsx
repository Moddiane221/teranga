import Link from "next/link";
import Image from "next/image";

type Props = {
  id: string;
  slug: string;
  title: string;
  price: number;
  currency: string;
  cityName: string;
  imageUrl?: string;
  isBoosted?: boolean;
};

const currencyFormatter = (amount: number, currency: string) =>
  new Intl.NumberFormat("fr-FR", { style: "currency", currency, maximumFractionDigits: 0 }).format(amount);

export default function PropertyCard({ slug, title, price, currency, cityName, imageUrl, isBoosted }: Props) {
  return (
    <Link
      href={`/annonces/${slug}`}
      className="group block rounded-2xl overflow-hidden bg-white border border-indigo-950/10 hover:shadow-xl hover:-translate-y-0.5 transition-all duration-200"
    >
      <div className="relative h-48 bg-indigo-950/5">
        {imageUrl ? (
          <Image src={imageUrl} alt={title} fill className="object-cover" />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-indigo-950/30 text-sm">
            Pas de photo
          </div>
        )}
        {isBoosted && (
          <span className="absolute top-3 left-3 rounded-full bg-sunset text-white text-xs font-semibold px-3 py-1">
            À la une
          </span>
        )}
      </div>
      <div className="p-4">
        <p className="font-display font-semibold text-lg truncate">{title}</p>
        <p className="text-sm text-indigo-950/60 mt-1">{cityName}</p>
        <p className="font-display font-bold text-baobab mt-3">{currencyFormatter(price, currency)}</p>
      </div>
    </Link>
  );
}
