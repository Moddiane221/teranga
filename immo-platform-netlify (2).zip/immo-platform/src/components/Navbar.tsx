import Link from "next/link";

export default function Navbar() {
  return (
    <header className="border-b border-indigo-950/10 bg-sable/95 backdrop-blur sticky top-0 z-40">
      <div className="mx-auto max-w-7xl px-6 h-16 flex items-center justify-between">
        <Link href="/" className="font-display font-bold text-xl tracking-tight">
          Teranga<span className="text-sunset">Immo</span>
        </Link>
        <nav className="hidden md:flex items-center gap-8 text-sm font-medium">
          <Link href="/annonces?type=VENTE" className="hover:text-sunset transition-colors">Achat</Link>
          <Link href="/annonces?type=LOCATION" className="hover:text-sunset transition-colors">Location</Link>
          <Link href="/annonces?type=TERRAIN" className="hover:text-sunset transition-colors">Terrains</Link>
          <Link href="/annonces?type=COMMERCE" className="hover:text-sunset transition-colors">Commerces</Link>
        </nav>
        <div className="flex items-center gap-3">
          <Link href="/connexion" className="text-sm font-medium hover:text-sunset transition-colors">
            Connexion
          </Link>
          <Link
            href="/publier"
            className="rounded-full bg-indigo-950 text-sable px-4 py-2 text-sm font-semibold hover:bg-baobab transition-colors"
          >
            Publier une annonce
          </Link>
        </div>
      </div>
    </header>
  );
}
