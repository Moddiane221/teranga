export default function Footer() {
  return (
    <footer className="bg-indigo-950 text-sable/80 mt-24">
      <div className="mx-auto max-w-7xl px-6 py-12 grid grid-cols-2 md:grid-cols-4 gap-8 text-sm">
        <div>
          <p className="font-display font-bold text-lg text-sable mb-3">
            Teranga<span className="text-sunset">Immo</span>
          </p>
          <p>La marketplace immobilière moderne, pensée pour l'Afrique de l'Ouest.</p>
        </div>
        <div>
          <p className="font-semibold text-sable mb-3">Annonces</p>
          <ul className="space-y-2">
            <li>Vente</li>
            <li>Location</li>
            <li>Location saisonnière</li>
            <li>Terrains &amp; commerces</li>
          </ul>
        </div>
        <div>
          <p className="font-semibold text-sable mb-3">Compte</p>
          <ul className="space-y-2">
            <li>Publier une annonce</li>
            <li>Espace agence</li>
            <li>Packs &amp; tarifs</li>
          </ul>
        </div>
        <div>
          <p className="font-semibold text-sable mb-3">Paiements acceptés</p>
          <p>Wave · Orange Money · Free Money · Visa · Mastercard · PayPal</p>
        </div>
      </div>
      <div className="border-t border-sable/10 py-4 text-center text-xs text-sable/50">
        © {new Date().getFullYear()} TerangaImmo. Tous droits réservés.
      </div>
    </footer>
  );
}
