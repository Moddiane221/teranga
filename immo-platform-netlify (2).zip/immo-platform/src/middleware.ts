import { NextRequest, NextResponse } from "next/server";
import { getSessionFromRequest } from "@/lib/auth";

const roleProtectedPrefixes: { prefix: string; roles: string[] }[] = [
  { prefix: "/admin", roles: ["ADMIN"] },
  { prefix: "/tableau-de-bord", roles: ["ADMIN", "AGENCE", "AGENT", "PROPRIETAIRE", "ACHETEUR"] },
  { prefix: "/publier", roles: ["ADMIN", "AGENCE", "AGENT", "PROPRIETAIRE"] },
];

export function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;
  const rule = roleProtectedPrefixes.find((r) => pathname.startsWith(r.prefix));
  if (!rule) return NextResponse.next();

  const session = getSessionFromRequest(req);
  if (!session || !rule.roles.includes(session.role)) {
    const loginUrl = new URL("/connexion", req.url);
    loginUrl.searchParams.set("redirect", pathname);
    return NextResponse.redirect(loginUrl);
  }
  return NextResponse.next();
}

export const config = {
  matcher: ["/admin/:path*", "/tableau-de-bord/:path*", "/publier/:path*"],
};
