import { prisma } from "@/lib/prisma";
import Image from "next/image";
import { notFound } from "next/navigation";
import type { Metadata } from "next";

async function getProperty(slug: string) {
  return prisma.property.findUnique({
    where: { slug },
    include: {
      images: { orderBy: { position: "asc" } },
      city: { include: { country: true } },
      owner: { select: { firstName: true, lastName: true, phone: true, agencyName: true } },
    },
  });
}

export async function generateMetadata({ params }: { params: { id: string } }): Promise<Metadata> {
  const property = await getProperty(params.id).catch(() => null);
  if (!property) return {};
  return {
    title: property.metaTitle || `${property.title} — TerangaImmo`,
    description: property.metaDescription || property.description.slice(0, 155),
  };
}

export default async function PropertyDetailPage({ params }: { params: { id: string } }) {
  const property = await getProperty(params.id).catch(() => null);
  if (!property) return notFound();

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "RealEstateListing",
    name: property.title,
    description: property.description,
    url: `${process.env.NEXT_PUBLIC_SITE_URL || ""}/annonces/${property.slug}`,
    offers: {
      "@type": "Offer",
      price: property.price.toString(),
      priceCurrency: property.currency,
    },
    address: {
      "@type": "PostalAddress",
      streetAddress: property.address,
      addressLocality: property.city?.name,
      addressCountry: property.city?.country?.name,
    },
  };

  return (
    <div className="mx-auto max-w-5xl px-6 py-10">
      {/* Balisage structuré pour le référencement (Google, schema.org) */}
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />

      <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mb-8 rounded-2xl overflow-hidden">
        {property.images.slice(0, 5).map((img, i) => (
          <div key={img.id} className={`relative h-64 ${i === 0 ? "col-span-2 row-span-2" : ""}`}>
            <Image src={img.url} alt={property.title} fill className="object-cover" />
          </div>
        ))}
        {property.images.length === 0 && (
          <div className="col-span-4 h-64 bg-indigo-950/5 flex items-center justify-center text-indigo-950/30">
            Aucune photo
          </div>
        )}
      </div>

      <div className="grid md:grid-cols-3 gap-10">
        <div className="md:col-span-2">
          <h1 className="font-display text-3xl font-bold">{property.title}</h1>
          <p className="text-indigo-950/60 mt-1">
            {property.address}, {property.city?.name}
          </p>
          <p className="font-display text-2xl font-bold text-baobab mt-4">
            {new Intl.NumberFormat("fr-FR", { style: "currency", currency: property.currency, maximumFractionDigits: 0 }).format(Number(property.price))}
          </p>

          <div className="flex gap-6 mt-6 text-sm text-indigo-950/70">
            {property.surface && <span>{property.surface} m²</span>}
            {property.rooms && <span>{property.rooms} pièces</span>}
            {property.bedrooms && <span>{property.bedrooms} chambres</span>}
          </div>

          <p className="mt-8 whitespace-pre-line leading-relaxed">{property.description}</p>
        </div>

        <aside className="border border-indigo-950/10 rounded-2xl p-6 h-fit">
          <p className="font-semibold">
            {property.owner.agencyName || `${property.owner.firstName} ${property.owner.lastName}`}
          </p>
          {property.owner.phone && <p className="text-sm text-indigo-950/60 mt-1">{property.owner.phone}</p>}
          <button className="mt-4 w-full rounded-xl bg-indigo-950 text-sable py-3 font-semibold hover:bg-baobab transition-colors">
            Envoyer un message
          </button>
          <button className="mt-2 w-full rounded-xl border border-indigo-950/20 py-3 font-semibold hover:border-baobab transition-colors">
            Ajouter aux favoris
          </button>
        </aside>
      </div>
    </div>
  );
}
