import SearchBar from "@/components/SearchBar";
import PropertyCard from "@/components/PropertyCard";
import { prisma } from "@/lib/prisma";

export default async function AnnoncesPage({
  searchParams,
}: {
  searchParams: { q?: string; type?: string; ville?: string; page?: string };
}) {
  const page = Number(searchParams.page || "1");
  const pageSize = 12;

  const where: any = { status: "PUBLIEE" };
  if (searchParams.ville) where.city = { name: { equals: searchParams.ville, mode: "insensitive" } };
  if (searchParams.type) where.type = searchParams.type;
  if (searchParams.q) {
    where.OR = [
      { title: { contains: searchParams.q, mode: "insensitive" } },
      { description: { contains: searchParams.q, mode: "insensitive" } },
    ];
  }

  const [items, total] = await Promise.all([
    prisma.property
      .findMany({
        where,
        include: { images: { take: 1, orderBy: { position: "asc" } }, city: true, boosts: true },
        orderBy: { createdAt: "desc" },
        skip: (page - 1) * pageSize,
        take: pageSize,
      })
      .catch(() => []),
    prisma.property.count({ where }).catch(() => 0),
  ]);

  return (
    <div className="mx-auto max-w-7xl px-6 py-10">
      <div className="mb-10">
        <SearchBar />
      </div>
      <p className="text-sm text-indigo-950/50 mb-6">{total} annonce{total > 1 ? "s" : ""} trouvée{total > 1 ? "s" : ""}</p>

      {items.length === 0 ? (
        <p className="text-indigo-950/50">Aucune annonce ne correspond à votre recherche.</p>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {items.map((p) => (
            <PropertyCard
              key={p.id}
              id={p.id}
              slug={p.slug}
              title={p.title}
              price={Number(p.price)}
              currency={p.currency}
              cityName={p.city?.name ?? ""}
              imageUrl={p.images[0]?.url}
              isBoosted={p.boosts.length > 0}
            />
          ))}
        </div>
      )}
    </div>
  );
}
