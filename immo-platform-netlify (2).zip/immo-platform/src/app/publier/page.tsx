"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export default function PublierPage() {
  const router = useRouter();
  const [form, setForm] = useState({
    title: "", description: "", type: "VENTE", price: "", address: "", cityId: "",
  });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  function update(field: string, value: string) {
    setForm((f) => ({ ...f, [field]: value }));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError("");
    const res = await fetch("/api/properties", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...form, price: Number(form.price), images: [] }),
    });
    setLoading(false);
    if (!res.ok) {
      const data = await res.json();
      setError("Vérifiez les champs du formulaire.");
      return;
    }
    router.push("/tableau-de-bord");
  }

  return (
    <div className="mx-auto max-w-2xl px-6 py-16">
      <h1 className="font-display text-3xl font-bold mb-2">Publier une annonce</h1>
      <p className="text-indigo-950/60 mb-8">
        Votre annonce sera visible publiquement après validation par notre équipe de modération.
      </p>
      <form onSubmit={handleSubmit} className="flex flex-col gap-4">
        <input required placeholder="Titre de l'annonce" value={form.title} onChange={(e) => update("title", e.target.value)} className="rounded-xl px-4 py-3 bg-white border border-indigo-950/10" />
        <textarea required rows={5} placeholder="Description détaillée" value={form.description} onChange={(e) => update("description", e.target.value)} className="rounded-xl px-4 py-3 bg-white border border-indigo-950/10" />
        <div className="grid grid-cols-2 gap-4">
          <select value={form.type} onChange={(e) => update("type", e.target.value)} className="rounded-xl px-4 py-3 bg-white border border-indigo-950/10">
            <option value="VENTE">Vente</option>
            <option value="LOCATION">Location</option>
            <option value="LOCATION_SAISONNIERE">Location saisonnière</option>
            <option value="TERRAIN">Terrain</option>
            <option value="COMMERCE">Commerce</option>
            <option value="HOTEL">Hôtel</option>
          </select>
          <input required type="number" placeholder="Prix" value={form.price} onChange={(e) => update("price", e.target.value)} className="rounded-xl px-4 py-3 bg-white border border-indigo-950/10" />
        </div>
        <input required placeholder="Adresse" value={form.address} onChange={(e) => update("address", e.target.value)} className="rounded-xl px-4 py-3 bg-white border border-indigo-950/10" />
        <input required placeholder="Identifiant de la ville (cityId)" value={form.cityId} onChange={(e) => update("cityId", e.target.value)} className="rounded-xl px-4 py-3 bg-white border border-indigo-950/10" />
        <p className="text-xs text-indigo-950/40 -mt-2">
          L'ajout de photos (jusqu'à 30), vidéos et carte interactive se branche ensuite via un composant d'upload (ex. Cloudinary/S3), non inclus dans ce squelette.
        </p>
        {error && <p className="text-sm text-red-600">{error}</p>}
        <button type="submit" disabled={loading} className="rounded-xl bg-indigo-950 text-sable py-3 font-semibold hover:bg-baobab transition-colors disabled:opacity-50">
          {loading ? "Publication..." : "Soumettre l'annonce"}
        </button>
      </form>
    </div>
  );
}
