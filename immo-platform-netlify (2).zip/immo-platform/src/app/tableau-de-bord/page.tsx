import { cookies } from "next/headers";
import { verifySession, SESSION_COOKIE_NAME } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import PropertyCard from "@/components/PropertyCard";

export default async function TableauDeBordPage() {
  const token = cookies().get(SESSION_COOKIE_NAME)?.value;
  const session = token ? verifySession(token) : null;
  if (!session) return null; // le middleware redirige déjà les visiteurs non connectés

  const [myProperties, favorites] = await Promise.all([
    prisma.property.findMany({
      where: { ownerId: session.userId },
      include: { images: { take: 1 }, city: true, boosts: true },
      orderBy: { createdAt: "desc" },
    }),
    prisma.favorite.findMany({
      where: { userId: session.userId },
      include: { property: { include: { images: { take: 1 }, city: true, boosts: true } } },
    }),
  ]);

  return (
    <div className="mx-auto max-w-7xl px-6 py-10">
      <h1 className="font-display text-3xl font-bold mb-8">Mon tableau de bord</h1>

      <section className="mb-12">
        <div className="flex items-baseline justify-between mb-4">
          <h2 className="font-display text-xl font-semibold">Mes annonces ({myProperties.length})</h2>
          <a href="/publier" className="text-sm font-semibold text-baobab hover:underline">+ Publier une annonce</a>
        </div>
        {myProperties.length === 0 ? (
          <p className="text-indigo-950/50 text-sm">Vous n'avez publié aucune annonce pour l'instant.</p>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {myProperties.map((p) => (
              <div key={p.id} className="relative">
                <PropertyCard id={p.id} slug={p.slug} title={p.title} price={Number(p.price)} currency={p.currency} cityName={p.city?.name ?? ""} imageUrl={p.images[0]?.url} isBoosted={p.boosts.length > 0} />
                <span className="absolute top-3 right-3 rounded-full bg-indigo-950 text-sable text-xs px-3 py-1">
                  {p.status}
                </span>
              </div>
            ))}
          </div>
        )}
      </section>

      <section className="mb-12">
        <h2 className="font-display text-xl font-semibold mb-4">Mes favoris ({favorites.length})</h2>
        {favorites.length === 0 ? (
          <p className="text-indigo-950/50 text-sm">Aucun favori pour le moment.</p>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {favorites.map((f) => (
              <PropertyCard key={f.id} id={f.property.id} slug={f.property.slug} title={f.property.title} price={Number(f.property.price)} currency={f.property.currency} cityName={f.property.city?.name ?? ""} imageUrl={f.property.images[0]?.url} isBoosted={f.property.boosts.length > 0} />
            ))}
          </div>
        )}
      </section>

      <section className="rounded-2xl border border-indigo-950/10 p-6">
        <h2 className="font-display text-xl font-semibold mb-2">Passer à un pack supérieur</h2>
        <p className="text-sm text-indigo-950/60 mb-4">
          Boostez vos annonces (À la une, Premium, Urgent, Coup de cœur) et publiez sans limite.
        </p>
        <form action="/api/payments/stripe/checkout" method="POST" className="flex gap-2">
          {/* En pratique : appeler l'API en fetch() côté client puis rediriger vers session.url */}
          <a href="#" className="rounded-xl bg-sunset text-white font-semibold px-5 py-2.5 text-sm">
            Voir les packs
          </a>
        </form>
      </section>
    </div>
  );
}
