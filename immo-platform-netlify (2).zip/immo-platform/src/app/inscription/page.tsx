"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

const roles = [
  { value: "ACHETEUR", label: "Acheteur / Locataire" },
  { value: "PROPRIETAIRE", label: "Propriétaire" },
  { value: "AGENT", label: "Agent immobilier" },
  { value: "AGENCE", label: "Agence" },
];

export default function InscriptionPage() {
  const router = useRouter();
  const [form, setForm] = useState({
    firstName: "", lastName: "", email: "", password: "", role: "ACHETEUR", phone: "", agencyName: "",
  });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  function update(field: string, value: string) {
    setForm((f) => ({ ...f, [field]: value }));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError("");
    const res = await fetch("/api/auth/register", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    });
    setLoading(false);
    if (!res.ok) {
      const data = await res.json();
      setError(typeof data.error === "string" ? data.error : "Impossible de créer le compte.");
      return;
    }
    router.push("/tableau-de-bord");
    router.refresh();
  }

  return (
    <div className="mx-auto max-w-md px-6 py-16">
      <h1 className="font-display text-3xl font-bold mb-8">Créer un compte</h1>
      <form onSubmit={handleSubmit} className="flex flex-col gap-4">
        <div className="grid grid-cols-2 gap-4">
          <input required placeholder="Prénom" value={form.firstName} onChange={(e) => update("firstName", e.target.value)} className="rounded-xl px-4 py-3 bg-white border border-indigo-950/10" />
          <input required placeholder="Nom" value={form.lastName} onChange={(e) => update("lastName", e.target.value)} className="rounded-xl px-4 py-3 bg-white border border-indigo-950/10" />
        </div>
        <input required type="email" placeholder="E-mail" value={form.email} onChange={(e) => update("email", e.target.value)} className="rounded-xl px-4 py-3 bg-white border border-indigo-950/10" />
        <input placeholder="Téléphone" value={form.phone} onChange={(e) => update("phone", e.target.value)} className="rounded-xl px-4 py-3 bg-white border border-indigo-950/10" />
        <input required type="password" placeholder="Mot de passe (8 caractères min.)" value={form.password} onChange={(e) => update("password", e.target.value)} className="rounded-xl px-4 py-3 bg-white border border-indigo-950/10" />
        <select value={form.role} onChange={(e) => update("role", e.target.value)} className="rounded-xl px-4 py-3 bg-white border border-indigo-950/10">
          {roles.map((r) => <option key={r.value} value={r.value}>{r.label}</option>)}
        </select>
        {form.role === "AGENCE" && (
          <input placeholder="Nom de l'agence" value={form.agencyName} onChange={(e) => update("agencyName", e.target.value)} className="rounded-xl px-4 py-3 bg-white border border-indigo-950/10" />
        )}
        {error && <p className="text-sm text-red-600">{error}</p>}
        <button type="submit" disabled={loading} className="rounded-xl bg-indigo-950 text-sable py-3 font-semibold hover:bg-baobab transition-colors disabled:opacity-50">
          {loading ? "Création..." : "Créer mon compte"}
        </button>
      </form>
    </div>
  );
}
