import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { constructStripeEvent } from "@/lib/payments/stripe";

// Stripe a besoin du corps brut de la requête pour vérifier la signature.
export const runtime = "nodejs";

export async function POST(req: NextRequest) {
  const rawBody = await req.text();
  const signature = req.headers.get("stripe-signature");
  if (!signature) return NextResponse.json({ error: "Signature manquante." }, { status: 400 });

  let event;
  try {
    event = constructStripeEvent(rawBody, signature);
  } catch (err) {
    return NextResponse.json({ error: "Signature invalide." }, { status: 400 });
  }

  if (event.type === "checkout.session.completed") {
    const checkoutSession = event.data.object as { id: string; metadata?: Record<string, string> };

    const payment = await prisma.payment.findFirst({ where: { providerRef: checkoutSession.id } });
    if (payment) {
      await prisma.payment.update({
        where: { id: payment.id },
        data: { status: "REUSSI" },
      });

      const { userId, packageId } = checkoutSession.metadata || {};
      if (userId && packageId) {
        const pack = await prisma.package.findUnique({ where: { id: packageId } });
        if (pack) {
          const endsAt = new Date();
          endsAt.setMonth(endsAt.getMonth() + 1);
          const subscription = await prisma.subscription.create({
            data: { userId, packageId, endsAt },
          });
          await prisma.payment.update({
            where: { id: payment.id },
            data: { subscriptionId: subscription.id },
          });
        }
      }
    }
  }

  return NextResponse.json({ received: true });
}
