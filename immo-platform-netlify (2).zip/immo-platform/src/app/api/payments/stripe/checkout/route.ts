import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getSessionFromRequest } from "@/lib/auth";
import { createStripeCheckoutSession } from "@/lib/payments/stripe";

// POST /api/payments/stripe/checkout  { packageType: "STANDARD" | "PREMIUM" | "PROFESSIONNEL" }
export async function POST(req: NextRequest) {
  const session = getSessionFromRequest(req);
  if (!session) return NextResponse.json({ error: "Non authentifié." }, { status: 401 });

  const { packageType } = await req.json();
  const pack = await prisma.package.findUnique({ where: { type: packageType } });
  if (!pack) return NextResponse.json({ error: "Pack introuvable." }, { status: 404 });

  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000";

  const checkoutSession = await createStripeCheckoutSession({
    amount: Number(pack.priceMonthly),
    currency: "usd",
    productName: `Abonnement ${pack.name}`,
    successUrl: `${siteUrl}/tableau-de-bord?paiement=succes`,
    cancelUrl: `${siteUrl}/tableau-de-bord?paiement=annule`,
    metadata: { userId: session.userId, packageId: pack.id },
  });

  await prisma.payment.create({
    data: {
      userId: session.userId,
      provider: "STRIPE",
      providerRef: checkoutSession.id,
      amount: pack.priceMonthly,
      currency: "USD",
      status: "EN_ATTENTE",
    },
  });

  return NextResponse.json({ url: checkoutSession.url });
}
