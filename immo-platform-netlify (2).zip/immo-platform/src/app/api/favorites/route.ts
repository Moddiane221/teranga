import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getSessionFromRequest } from "@/lib/auth";

export async function GET(req: NextRequest) {
  const session = getSessionFromRequest(req);
  if (!session) return NextResponse.json({ error: "Non authentifié." }, { status: 401 });

  const favorites = await prisma.favorite.findMany({
    where: { userId: session.userId },
    include: { property: { include: { images: { take: 1 }, city: true } } },
    orderBy: { createdAt: "desc" },
  });
  return NextResponse.json({ favorites });
}

export async function POST(req: NextRequest) {
  const session = getSessionFromRequest(req);
  if (!session) return NextResponse.json({ error: "Non authentifié." }, { status: 401 });

  const { propertyId } = await req.json();
  if (!propertyId) return NextResponse.json({ error: "propertyId requis." }, { status: 400 });

  const favorite = await prisma.favorite.upsert({
    where: { userId_propertyId: { userId: session.userId, propertyId } },
    create: { userId: session.userId, propertyId },
    update: {},
  });
  return NextResponse.json({ favorite }, { status: 201 });
}

export async function DELETE(req: NextRequest) {
  const session = getSessionFromRequest(req);
  if (!session) return NextResponse.json({ error: "Non authentifié." }, { status: 401 });

  const { propertyId } = await req.json();
  await prisma.favorite.deleteMany({ where: { userId: session.userId, propertyId } });
  return NextResponse.json({ success: true });
}
