import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getSessionFromRequest } from "@/lib/auth";

export async function GET(_req: NextRequest, { params }: { params: { id: string } }) {
  const property = await prisma.property.findUnique({
    where: { id: params.id },
    include: {
      images: { orderBy: { position: "asc" } },
      videos: true,
      city: { include: { country: true } },
      category: true,
      owner: { select: { id: true, firstName: true, lastName: true, phone: true, agencyName: true } },
      boosts: true,
    },
  });
  if (!property) return NextResponse.json({ error: "Annonce introuvable." }, { status: 404 });

  // Incrémente le compteur de vues (statistique simple, non bloquante côté utilisateur)
  await prisma.property.update({ where: { id: params.id }, data: { viewsCount: { increment: 1 } } });

  return NextResponse.json({ property });
}

export async function PUT(req: NextRequest, { params }: { params: { id: string } }) {
  const session = getSessionFromRequest(req);
  if (!session) return NextResponse.json({ error: "Non authentifié." }, { status: 401 });

  const property = await prisma.property.findUnique({ where: { id: params.id } });
  if (!property) return NextResponse.json({ error: "Annonce introuvable." }, { status: 404 });

  const isOwner = property.ownerId === session.userId;
  const isAdmin = session.role === "ADMIN";
  if (!isOwner && !isAdmin) return NextResponse.json({ error: "Non autorisé." }, { status: 403 });

  const body = await req.json();
  // Seul un admin peut changer le statut de modération directement
  const allowedFields = ["title", "description", "price", "address", "status"];
  const data: Record<string, unknown> = {};
  for (const key of allowedFields) {
    if (key === "status" && !isAdmin) continue;
    if (key in body) data[key] = body[key];
  }

  const updated = await prisma.property.update({ where: { id: params.id }, data });
  return NextResponse.json({ property: updated });
}

export async function DELETE(req: NextRequest, { params }: { params: { id: string } }) {
  const session = getSessionFromRequest(req);
  if (!session) return NextResponse.json({ error: "Non authentifié." }, { status: 401 });

  const property = await prisma.property.findUnique({ where: { id: params.id } });
  if (!property) return NextResponse.json({ error: "Annonce introuvable." }, { status: 404 });

  const isOwner = property.ownerId === session.userId;
  const isAdmin = session.role === "ADMIN";
  if (!isOwner && !isAdmin) return NextResponse.json({ error: "Non autorisé." }, { status: 403 });

  await prisma.property.delete({ where: { id: params.id } });
  return NextResponse.json({ success: true });
}
