import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { getSessionFromRequest } from "@/lib/auth";

// GET /api/properties?ville=Dakar&type=VENTE&prixMin=0&prixMax=100000000&q=villa
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const ville = searchParams.get("ville") || undefined;
  const type = searchParams.get("type") || undefined;
  const prixMin = searchParams.get("prixMin");
  const prixMax = searchParams.get("prixMax");
  const q = searchParams.get("q") || undefined;
  const page = Number(searchParams.get("page") || "1");
  const pageSize = 12;

  const where: any = { status: "PUBLIEE" };
  if (ville) where.city = { name: { equals: ville, mode: "insensitive" } };
  if (type) where.type = type;
  if (prixMin || prixMax) {
    where.price = {};
    if (prixMin) where.price.gte = Number(prixMin);
    if (prixMax) where.price.lte = Number(prixMax);
  }
  if (q) {
    where.OR = [
      { title: { contains: q, mode: "insensitive" } },
      { description: { contains: q, mode: "insensitive" } },
    ];
  }

  const [items, total] = await Promise.all([
    prisma.property.findMany({
      where,
      include: { images: { orderBy: { position: "asc" }, take: 1 }, city: { include: { country: true } }, boosts: true },
      orderBy: { createdAt: "desc" },
      skip: (page - 1) * pageSize,
      take: pageSize,
    }),
    prisma.property.count({ where }),
  ]);

  return NextResponse.json({ items, total, page, pageSize });
}

const createSchema = z.object({
  title: z.string().min(5),
  description: z.string().min(20),
  type: z.enum(["VENTE", "LOCATION", "LOCATION_SAISONNIERE", "TERRAIN", "COMMERCE", "HOTEL"]),
  price: z.number().positive(),
  currency: z.string().default("XOF"),
  surface: z.number().optional(),
  rooms: z.number().int().optional(),
  bedrooms: z.number().int().optional(),
  bathrooms: z.number().int().optional(),
  address: z.string().min(3),
  latitude: z.number().optional(),
  longitude: z.number().optional(),
  cityId: z.string(),
  categoryId: z.string().optional(),
  images: z.array(z.string().url()).max(30).default([]),
});

export async function POST(req: NextRequest) {
  const session = getSessionFromRequest(req);
  if (!session) return NextResponse.json({ error: "Non authentifié." }, { status: 401 });

  const body = await req.json();
  const parsed = createSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }
  const data = parsed.data;
  const slug = `${data.title.toLowerCase().replace(/[^a-z0-9]+/g, "-")}-${Date.now().toString(36)}`;

  const property = await prisma.property.create({
    data: {
      title: data.title,
      slug,
      description: data.description,
      type: data.type,
      price: data.price,
      currency: data.currency,
      surface: data.surface,
      rooms: data.rooms,
      bedrooms: data.bedrooms,
      bathrooms: data.bathrooms,
      address: data.address,
      latitude: data.latitude,
      longitude: data.longitude,
      cityId: data.cityId,
      categoryId: data.categoryId,
      ownerId: session.userId,
      status: "EN_ATTENTE", // toute annonce passe par la modération admin
      images: { create: data.images.map((url, i) => ({ url, position: i })) },
    },
    include: { images: true },
  });

  return NextResponse.json({ property }, { status: 201 });
}
