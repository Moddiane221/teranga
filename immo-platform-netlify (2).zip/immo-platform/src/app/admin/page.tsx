import { prisma } from "@/lib/prisma";

export default async function AdminPage() {
  const [pendingCount, publishedCount, userCount, revenue] = await Promise.all([
    prisma.property.count({ where: { status: "EN_ATTENTE" } }),
    prisma.property.count({ where: { status: "PUBLIEE" } }),
    prisma.user.count(),
    prisma.payment.aggregate({ where: { status: "REUSSI" }, _sum: { amount: true } }),
  ]);

  const pendingListings = await prisma.property.findMany({
    where: { status: "EN_ATTENTE" },
    include: { owner: true, city: true },
    orderBy: { createdAt: "asc" },
    take: 20,
  });

  return (
    <div className="mx-auto max-w-7xl px-6 py-10">
      <h1 className="font-display text-3xl font-bold mb-8">Administration</h1>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-10">
        {[
          { label: "Annonces en attente", value: pendingCount },
          { label: "Annonces publiées", value: publishedCount },
          { label: "Utilisateurs", value: userCount },
          { label: "Revenus encaissés", value: `${revenue._sum.amount ?? 0}` },
        ].map((stat) => (
          <div key={stat.label} className="rounded-2xl border border-indigo-950/10 p-5 bg-white">
            <p className="text-2xl font-display font-bold">{stat.value}</p>
            <p className="text-sm text-indigo-950/60">{stat.label}</p>
          </div>
        ))}
      </div>

      <h2 className="font-display text-xl font-semibold mb-4">Annonces à modérer</h2>
      <div className="rounded-2xl border border-indigo-950/10 overflow-hidden bg-white">
        <table className="w-full text-sm">
          <thead className="bg-indigo-950/5 text-left">
            <tr>
              <th className="p-3">Titre</th>
              <th className="p-3">Ville</th>
              <th className="p-3">Auteur</th>
              <th className="p-3">Actions</th>
            </tr>
          </thead>
          <tbody>
            {pendingListings.map((p) => (
              <tr key={p.id} className="border-t border-indigo-950/5">
                <td className="p-3">{p.title}</td>
                <td className="p-3">{p.city?.name}</td>
                <td className="p-3">{p.owner.firstName} {p.owner.lastName}</td>
                <td className="p-3 flex gap-2">
                  <button className="rounded-lg bg-baobab text-white px-3 py-1.5 text-xs font-semibold">Valider</button>
                  <button className="rounded-lg bg-red-600 text-white px-3 py-1.5 text-xs font-semibold">Refuser</button>
                </td>
              </tr>
            ))}
            {pendingListings.length === 0 && (
              <tr><td colSpan={4} className="p-6 text-center text-indigo-950/40">Aucune annonce en attente.</td></tr>
            )}
          </tbody>
        </table>
      </div>
      <p className="text-xs text-indigo-950/40 mt-4">
        Les boutons Valider/Refuser sont à connecter à PUT /api/properties/[id] avec status=PUBLIEE ou REFUSEE.
      </p>
    </div>
  );
}
