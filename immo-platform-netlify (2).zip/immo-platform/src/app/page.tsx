import SearchBar from "@/components/SearchBar";
import PropertyCard from "@/components/PropertyCard";
import { prisma } from "@/lib/prisma";

export const revalidate = 60;

export default async function HomePage() {
  const featured = await prisma.property
    .findMany({
      where: { status: "PUBLIEE" },
      include: { images: { take: 1, orderBy: { position: "asc" } }, city: true, boosts: true },
      orderBy: { createdAt: "desc" },
      take: 8,
    })
    .catch(() => []); // en l'absence de base de données configurée, on affiche une page vide gracieuse

  return (
    <div>
      <section className="bg-indigo-950 text-sable">
        <div className="mx-auto max-w-7xl px-6 py-20 flex flex-col items-start gap-8">
          <div>
            <p className="uppercase tracking-widest text-sunset text-xs font-semibold mb-4">
              Vente · Location · Terrains · Commerces
            </p>
            <h1 className="font-display text-4xl md:text-6xl font-bold max-w-2xl leading-tight">
              Le bien qu'il vous faut, là où vous le cherchez.
            </h1>
            <p className="mt-4 text-sable/70 max-w-xl">
              Des milliers d'annonces vérifiées, publiées par des agences, agents et propriétaires. Cherchez, comparez, contactez — en toute confiance.
            </p>
          </div>
          <SearchBar />
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-6 py-16">
        <div className="flex items-baseline justify-between mb-8">
          <h2 className="font-display text-2xl font-bold">Annonces à la une</h2>
          <a href="/annonces" className="text-sm font-semibold text-baobab hover:underline">
            Voir toutes les annonces →
          </a>
        </div>

        {featured.length === 0 ? (
          <p className="text-indigo-950/50 text-sm">
            Aucune annonce à afficher pour le moment. Connectez une base de données et publiez votre première annonce pour la voir apparaître ici.
          </p>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {featured.map((p) => (
              <PropertyCard
                key={p.id}
                id={p.id}
                slug={p.slug}
                title={p.title}
                price={Number(p.price)}
                currency={p.currency}
                cityName={p.city?.name ?? ""}
                imageUrl={p.images[0]?.url}
                isBoosted={p.boosts.length > 0}
              />
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
